								</form>
							</div>
						</div>
					</div><!--display-->
				</div><!--fpbx-->
			</div><!--Column-->
		</div>
		<div class="col-sm-3 hidden-xs bootnav">
			<div class="list-group">
				<?php echo $rnav_list ?>
			</div>
		</div>
	</div><!--row-->
</div><!--Container-->
